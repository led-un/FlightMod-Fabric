package com.github.flightmod.modules;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class NoFall {
    private final class_310 mc = class_310.method_1551();
    private boolean enabled = false;
    private static boolean noFallActive = false;

    public void toggle() {
        noFallActive = this.enabled = !this.enabled;
        class_746 player = this.mc.field_1724;
        if (player == null) {
            return;
        }
        if (this.enabled) {
            player.method_7353(class_2561.method_43470("§a[NoFall] §f已开启"), true);
        } else {
            player.method_7353(class_2561.method_43470("§c[NoFall] §f已关闭"), true);
        }
    }

    public void onClientTick(class_310 client) {
        // NoFall works entirely through the Mixin, no tick logic needed
    }

    public boolean shouldForceOnGround() {
        if (!this.enabled) {
            return false;
        }
        class_746 player = this.mc.field_1724;
        if (player == null) {
            return false;
        }
        if (player.method_24828()) {
            return false;
        }
        if (player.method_31549().field_7477) {
            return false;
        }
        // Trigger whenever falling (not ascending), not only at high speed
        return player.method_18798().field_1351 < 0.0;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public static boolean isNoFallActive() {
        return noFallActive;
    }
}
