package com.github.flightmod.modules;

import java.lang.reflect.Field;
import net.minecraft.class_1656;
import net.minecraft.class_2561;
import net.minecraft.class_2842;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class Flight {
    private final class_310 mc = class_310.method_1551();
    private boolean enabled = false;
    private float speed = 0.1f;

    private static Field flyingSpeedField = null;

    static {
        try {
            flyingSpeedField = class_1656.class.getDeclaredField("flyingSpeed");
            flyingSpeedField.setAccessible(true);
        } catch (Exception ignored) {
        }
    }

    private static void setFlySpeed(class_1656 abilities, float speed) {
        if (flyingSpeedField != null) {
            try {
                flyingSpeedField.setFloat(abilities, speed);
            } catch (Exception ignored) {
            }
        }
    }

    public void toggle() {
        this.enabled = !this.enabled;
        class_746 player = this.mc.field_1724;
        if (player == null) {
            return;
        }
        if (this.enabled) {
            this.onActivate(player);
            player.method_7353(class_2561.method_43470("§a[Flight] §f已开启"), true);
        } else {
            this.onDeactivate(player);
            player.method_7353(class_2561.method_43470("§c[Flight] §f已关闭"), true);
        }
    }

    private void onActivate(class_746 player) {
        if (!player.method_7337()) {
            class_1656 abilities = player.method_31549();
            abilities.field_7478 = true;
            if (!abilities.field_7477) {
                abilities.field_7479 = true;
            }
            setFlySpeed(abilities, this.speed);
            this.sendAbilitiesPacket();
        }
    }

    private void onDeactivate(class_746 player) {
        if (!player.method_7337()) {
            class_1656 abilities = player.method_31549();
            abilities.field_7478 = false;
            setFlySpeed(abilities, 0.05f);
            if (!abilities.field_7477) {
                abilities.field_7479 = false;
            }
            this.sendAbilitiesPacket();
        }
    }

    public void onClientTick(class_310 client) {
        if (!this.enabled || this.mc.field_1724 == null) {
            return;
        }
        class_746 player = this.mc.field_1724;

        if (!player.method_7337()) {
            player.method_31549().field_7478 = true;
            setFlySpeed(player.method_31549(), this.speed);
        }
    }

    private void sendAbilitiesPacket() {
        if (this.mc.field_1724 != null && this.mc.method_1562() != null) {
            this.mc.method_1562().method_52787(new class_2842(this.mc.field_1724.method_31549()));
        }
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public float getSpeed() {
        return this.speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }
}
