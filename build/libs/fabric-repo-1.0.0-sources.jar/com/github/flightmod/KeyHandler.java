package com.github.flightmod;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyHandler {
    private final class_310 mc = class_310.method_1551();
    private class_304 flightKey;
    private class_304 noFallKey;

    private boolean fPressed = false;
    private boolean nPressed = false;

    public void registerKeys() {
        flightKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.flightmod.flight",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                "category.flightmod"
        ));

        noFallKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.flightmod.nofall",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                "category.flightmod"
        ));
    }

    public void onClientTick(class_310 client) {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            return;
        }

        // Flight toggle (J key)
        if (flightKey != null && flightKey.method_1434()) {
            if (!fPressed) {
                fPressed = true;
                FlightMod.getFlight().toggle();
            }
        } else {
            fPressed = false;
        }

        // NoFall toggle (K key)
        if (noFallKey != null && noFallKey.method_1434()) {
            if (!nPressed) {
                nPressed = true;
                FlightMod.getNoFall().toggle();
            }
        } else {
            nPressed = false;
        }
    }
}
