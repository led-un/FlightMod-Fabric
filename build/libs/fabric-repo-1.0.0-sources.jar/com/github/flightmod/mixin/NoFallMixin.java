package com.github.flightmod.mixin;

import com.github.flightmod.FlightMod;
import com.github.flightmod.modules.NoFall;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class NoFallMixin {

    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"))
    private void onSendPacket(class_2596<?> packet, CallbackInfo ci) {
        if (!(packet instanceof class_2828)) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        if (mc.field_1724.method_31549().field_7477) {
            return;
        }
        if (!NoFall.isNoFallActive()) {
            return;
        }
        NoFall noFall = FlightMod.getNoFall();
        if (noFall == null || !noFall.isEnabled()) {
            return;
        }
        if (mc.field_1724.method_18798().field_1351 > 0.0) {
            return;
        }
        if (mc.field_1724.method_24828()) {
            return;
        }

        // Use Accessor Mixin to set onGround
        ((ServerboundMovePlayerPacketAccessor) packet).setOnGround(true);
    }
}
