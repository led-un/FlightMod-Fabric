package com.github.flightmod.mixin;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2828.class)
public interface ServerboundMovePlayerPacketAccessor {
    @Accessor("onGround")
    void setOnGround(boolean onGround);
}
